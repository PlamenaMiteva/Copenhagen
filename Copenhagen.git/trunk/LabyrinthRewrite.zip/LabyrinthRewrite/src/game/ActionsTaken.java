package game;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ActionsTaken extends KeyAdapter{
	Game game;
	public ActionsTaken(Game game){
		this.game=game;
	}
	public void keyPressed(KeyEvent event) {
		game.keyPressed(event);
	}
	
	public void keyReleased(KeyEvent event) {
		game.keyReleased(event);
	}
}
