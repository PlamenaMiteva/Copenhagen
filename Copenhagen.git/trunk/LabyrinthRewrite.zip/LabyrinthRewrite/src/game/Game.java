package game;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Timer;

import javax.swing.JFrame;

public class Game extends Canvas implements Runnable{
	
	private static final long serialVersionUID = 9096234119711419178L;
	//constants because these values are the same for all classes in the project
	public static final int WIDTH = 454;
	public static final int HEIGHT = 480;
	public static final int SCALE = 1;
	public static final String TITLE ="Labyrinth";
	//public Timer timer;
	private boolean running=false;
	private Thread thread;
	private Map m;
	
	//loads the image before it projects it
	private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
	private BufferedImage spriteSheet=null;
	private BufferedImage ground;
	private BufferedImage wall;
	private BufferedImage door;
	private BufferedImage exit;
	private Player p;
	
//	public Game() {
//		addKeyListener(new ActionsTaken(this));
//		setFocusable(true);
//		timer= new Timer(5,this);
//		timer.start();
//	}
	//temp
	//private BufferedImage player;
	
	//initializing
	//call after all  threads
	public void init() {
		requestFocus();
		BufferedImageLoader loader = new BufferedImageLoader();
		try {
			ground=loader.loadImage("/ground.png");
			spriteSheet=loader.loadImage("/turtleImage.png");
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		

		
		addKeyListener(new ActionsTaken(this));
		//setFocusable(true);
		m=new Map();
		m.openFile();
		m.readFile();
		m.closeFile();
		p=new Player(1,1,this);
		//addKeyListener(new ActionsTaken(this));
		
//		SpriteSheet ss = new SpriteSheet(spriteSheet);
//		//width of single sprite=38
//		//height of single sprite=50
//		player= ss.grabImage(1, 1, 38, 50);
		
	}
	
	private synchronized void start() {
		if(running) {
			return;
		}
		running=true;
		thread = new Thread(this);
		thread.start();
	}
	
	
	private synchronized void stop() {
		if(!running) {
			return;
		}
		running = false;
		try {
			thread.join(); // joins all the threads together
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.exit(1);
	}
	
	// Here we should put all the updates of the game
	@Override
	public void run() {
		init();
		long lastTime = System.nanoTime();
		final double amountOfTicks = 30.0;
		double ns = 1000000000 /amountOfTicks;
		//delta calculates the time past so it will catch up if it's running slower
		double delta = 0;
		int updates = 0;
		int frames = 0;
		long timer = System.currentTimeMillis();
		while(running) {
			long now = System.nanoTime();
			delta+=(now-lastTime)/ns;
			lastTime = now;
			//System.out.println("WORKING");
			//make always delta equals to zero 
			if (delta>=1) {
				tick();
				updates++;
				delta--;
			}
			render();
			frames++;
			if (System.currentTimeMillis()-timer>1000) {
				timer+=1000;
				System.out.println(updates+" Ticks, fps" +frames);
				updates = 0;
				frames = 0;
			}
		}
		stop();
	}

	//Everything in the game that updates
	private void tick() {
		p.tick();
	}
	
	//Everything that renders
	//Calls as much as it wants
	private void render() {
		//referring to the Canvas class
		//just initializing here and it is null
		BufferStrategy bs = this.getBufferStrategy();
		//when it is null we can create it
		if (bs==null) {
			//3 is because we load 3 images, it increases speed over time
			createBufferStrategy(3);
			return;
		}
		//Draw buffers
		Graphics g = bs.getDrawGraphics();
		///////////////////////////////////////////////
		//here we draw images
		g.drawImage(image, 0, 0, getWidth(), getHeight(),this);
		p.render(g);
		m.paint(g);
		
		//g.drawImage(player,100,100,this);
		/////////////////////////////////////////////
		//we should dispose it because or next time it will be null again
		g.dispose();
		bs.show();
	}
	
	public void keyPressed(KeyEvent event) {
		int key = event.getKeyCode();
		if ((key == KeyEvent.VK_RIGHT) || key ==KeyEvent.VK_D) {
			if (!m.getMap(p.getX(), p.getY() - 1).equals(",") && !m.getMap(p.getX(), p.getY() - 1).equals("d")) {
				p.setVelX(3);
			}
		}
		else if ((key == KeyEvent.VK_LEFT) || key==KeyEvent.VK_A) {
			p.setVelX(-3);
		}
		else if ((key ==KeyEvent.VK_DOWN) || key==KeyEvent.VK_S) {
			p.setVelY(3);
		}
		else if((key == KeyEvent.VK_UP) || key== KeyEvent.VK_W) {
			p.setVelY(-3);
		}
//		//playing with WASD or UP, DOWN, LEFT, RIGHT arrows
//		int key = event.getKeyCode();
//		
//		//up
//		if ((key == KeyEvent.VK_W) || (key == KeyEvent.VK_UP)) {
//			if (!m.getMap(player.getX(), player.getY() - 1).equals(",") && !m.getMap(player.getX(), player.getY() - 1).equals("d")) {
//				player.move(0, -1);
//				
//			}
//		}
//		//down
//		else if ((key == KeyEvent.VK_S) || (key == KeyEvent.VK_DOWN)) {
//			if (!m.getMap(player.getX(), player.getY() + 1).equals(",") && !m.getMap(player.getX(), player.getY() + 1).equals("d")) {
//				player.move(0, 1);
//			}
//		}
//		//left
//		else if ((key == KeyEvent.VK_A) || (key == KeyEvent.VK_LEFT)) {
//			if (!m.getMap(player.getX() - 1, player.getY()).equals(",") && !m.getMap(player.getX() - 1, player.getY()).equals("d")) {
//				player.move(-1, 0);
//			}
//		}
//		//right
//		else if ((key == KeyEvent.VK_D) || (key == KeyEvent.VK_RIGHT)) {
//			if (!m.getMap(player.getX() + 1, player.getY()).equals(",") && !m.getMap(player.getX() + 1, player.getY()).equals("d")) {
//				player.move(1, 0);
//			}
//		}
	}
	
	public void keyReleased(KeyEvent event) {
		int key = event.getKeyCode();
		if ((key == KeyEvent.VK_RIGHT) || key ==KeyEvent.VK_D) {
			p.setVelX(0);
		}
		else if ((key == KeyEvent.VK_LEFT) || key==KeyEvent.VK_A) {
			p.setVelX(0);
		}
		else if ((key ==KeyEvent.VK_DOWN) || key==KeyEvent.VK_S) {
			p.setVelY(0);
		}
		else if((key == KeyEvent.VK_UP) || key== KeyEvent.VK_W) {
			p.setVelY(0);
		}
	}
	public static void main(String[] args) {
		Game game = new Game();
		game.setPreferredSize(new Dimension(WIDTH*SCALE, HEIGHT*SCALE));
		game.setMaximumSize(new Dimension(WIDTH*SCALE, HEIGHT*SCALE));
		game.setMinimumSize(new Dimension(WIDTH*SCALE, HEIGHT*SCALE));
		
		JFrame frame=new JFrame(game.TITLE);
		frame.add(game);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		// After making the frame of the game, we should start it
		game.start();
	}
	
	public BufferedImage getSpriteSheet() {
		return spriteSheet;
	}
}
