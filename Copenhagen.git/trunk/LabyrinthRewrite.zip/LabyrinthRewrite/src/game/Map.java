package game;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Map extends JFrame{
	public Scanner input;
	public String[] map = new String[14];
	//public Image ground, wall, exit, door;
	public BufferedImage wall;
	public BufferedImage ground;
	public BufferedImage exit;
	public BufferedImage door;
	//public BufferedImage ground, wall, exit, door;

	public Map() {
//		ImageIcon image = new ImageIcon("/ground.png");
		this.ground = ground;
//		image = new ImageIcon("/wall.png");
		this.wall =  wall;
//		image = new ImageIcon("/exit.png");
		this.exit =  exit;
//		image = new ImageIcon("/door.png");
		this.door =  door;		

		openFile();
		readFile();
		closeFile();
	}
	
	public BufferedImage getGround() {
		//BufferedImage gr= ground;
		return ground;
	}
//	public Image getGround() {
//		return ground;
//	}
	public BufferedImage getWall() {
		return wall;
	}
	public BufferedImage getExit() {
		return ground;
	}
	public BufferedImage getDoor() {
		return door;
	}

	public void openFile() {
		try {
			input = new Scanner(new File("resources/map1.txt"));
			//System.out.println("it is read");
		}
		catch (Exception e) {
			System.out.println("Cannot open map file!!!");
		}
	}

	public void readFile() {
		while(input.hasNext()) {
			for (int i = 0; i < 14; i++) {
				map[i] = input.next();
			}
		}
	}

	public void closeFile() {
		input.close();
	}
	
	public String getMap(int x, int y) {
		String index = map[y].substring(x, x + 1);
		return index;
	}
	
public void actionPerformed(ActionEvent e) {
		
		repaint();
//		if (m.getMap(player.getX(), player.getY()).equals("e")) {
//			JOptionPane.showMessageDialog(null, "YOU WON");
//		}
	}
public void paint(Graphics g) {
	super.paintComponents(g);
	
	for (int y = 0; y < 14; y++) {
		for (int x = 0; x < 14; x++) {
			if (getMap(x, y).equals("g")) {
				g.drawImage(getGround(), x * 32, y * 32, null);
				
			}
			else if (getMap(x, y).equals(",")) {
				g.drawImage(getWall(), x * 32, y * 32, null);
			}
			else if (getMap(x, y).equals("e")) {
				g.drawImage(getExit(), x * 32, y * 32, null);
			}
			else if (getMap(x, y).equals("d")) {
				g.drawImage(getDoor(), x * 32, y * 32, null);
			}
		}
	}
}
}
