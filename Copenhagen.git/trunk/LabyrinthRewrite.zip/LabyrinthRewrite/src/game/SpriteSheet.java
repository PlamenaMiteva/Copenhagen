package game;

import java.awt.image.BufferedImage;

public class SpriteSheet {
	private BufferedImage image;
	
	public SpriteSheet(BufferedImage image) {
		this.image=image;
	}
	
	//Grabbing and copying spritesheet
	public BufferedImage grabImage(int col, int row, int width, int height) {
		BufferedImage img=image.getSubimage((col*50)-50, (row*38)-38, width, height);
		return img;
	}
	
	
}
