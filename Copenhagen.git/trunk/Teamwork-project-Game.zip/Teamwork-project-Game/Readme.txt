Thank you for playing LABY the turtle.

The following instructions will guide you trough the steps for activating the sound in the game.

1. Under Board class, uncomment the line 48: "//music();" 
2. Under Board class again, mark everithing from line 348 to 367 and press Ctrl +"/" key. This will uncomment the music class.
3. In Eclipse go to the following option:
Windows -> Preferences -> Java -> Compiler -> Errors/Warnings Project -> Deprecated and restricted API and under Forbidden reference (access rules)” set the option to Warning or Ignore.

Now you can run the aplication again and the Sound should work.

Enjoy!

Team Copenhagen
